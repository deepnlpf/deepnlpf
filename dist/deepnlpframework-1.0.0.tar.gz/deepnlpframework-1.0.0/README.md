# DeepNLPF

<div align="center">
    <a href="#">
        <img alt="License" src="https://img.shields.io/github/license/deepnlpf/deepnlpf">
    </a>
    <a href="https://pypi.org/project/deepnlpf/">
        <img alt="PyPI Version" src="https://img.shields.io/pypi/v/deepnlpf?color=blue">
    </a>
    <a href="https://anaconda.org/deepnlpf">
        <img alt="Conda Versions" src="https://img.shields.io/conda/vn/deepnlpf?color=blue&label=conda">
    </a>
    <a href="https://pypi.org/project/deepnlpf/">
        <img alt="Python Versions" src="https://img.shields.io/pypi/pyversions/deepnlpf?colorB=blue">
    </a>
</div>