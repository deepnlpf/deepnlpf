# -*- coding: utf-8 -*-
"""
    Date: 01/03/2018
    Tutorial Baseline: [Sending Emails With Python](https://realpython.com/python-send-email/)
"""

class Email:

    def send():
        pass
        