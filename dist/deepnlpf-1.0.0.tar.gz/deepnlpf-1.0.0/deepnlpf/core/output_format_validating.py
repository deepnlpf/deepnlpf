# -*- coding: utf-8 -*-
""" ValidatingJSON
    Descrption:
    Create: 06/03/2019
    Library Baseline: https://github.com/Julian/jsonschema
"""

import json

class ValidatingJSON(object):
    
    def __init__(self):
       pass
