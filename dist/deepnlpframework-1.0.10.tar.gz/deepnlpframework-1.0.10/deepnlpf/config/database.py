# -*- coding: utf-8 -*-

DB = {
    'database': 'deepnlpf',
    'hostname': 'localhost',
    'port': 27017,
    'username': 'deep',
    'password': '123456'
}