# -*- coding: utf-8 -*-
class AdapterFormat(object):

    def __init__(self):
        pass

    def json_to_xml(self, id_corpus):
        pass

    def json_to_text(self, id_corpus):
        pass