# -*- coding: utf-8 -*-

TOAST = {
    'SEND_MSG': False
}

TELEGRAM = {
    'SEND_MSG': False,
    'TOKEN': '793078363:AAFs0Ie_-1_iLw9GGpJ4vnihbWo4K77aiLY',
    'CHAT_ID': '604669808',
}
